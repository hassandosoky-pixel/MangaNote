package com.example.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.DownloaderScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ManhwaDetailScreen
import com.example.ui.screens.ReaderScreen

@Composable
fun AppNavigation(viewModel: ManhwaViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "library") {
        composable("library") {
            LibraryScreen(
                viewModel = viewModel,
                onNavigateToDetail = { manhwaId ->
                    navController.navigate("detail/$manhwaId")
                },
                onNavigateToDownloader = {
                    navController.navigate("downloader")
                }
            )
        }
        composable("downloader") {
            DownloaderScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(
            "detail/{manhwaId}",
            arguments = listOf(navArgument("manhwaId") { type = NavType.StringType })
        ) { backStackEntry ->
            val manhwaId = backStackEntry.arguments?.getString("manhwaId") ?: return@composable
            ManhwaDetailScreen(
                manhwaId = manhwaId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToReader = { chapterId ->
                    navController.navigate("reader/$chapterId")
                }
            )
        }
        composable(
            "reader/{chapterId}",
            arguments = listOf(navArgument("chapterId") { type = NavType.StringType })
        ) { backStackEntry ->
            val chapterId = backStackEntry.arguments?.getString("chapterId") ?: return@composable
            ReaderScreen(
                chapterId = chapterId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
