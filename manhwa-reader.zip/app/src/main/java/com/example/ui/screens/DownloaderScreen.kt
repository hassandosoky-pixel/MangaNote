package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.ManhwaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloaderScreen(
    viewModel: ManhwaViewModel,
    onNavigateBack: () -> Unit
) {
    var urlInput by remember { mutableStateOf("") }
    val isScraping by viewModel.isScraping.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Download Manhwa") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.8f)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                label = { Text("Enter Manhwa URL") },
                placeholder = { Text("e.g. https://mangalek.com/manga/title") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { 
                    if (urlInput.isNotBlank()) {
                        viewModel.addManhwaFromUrl(urlInput)
                    }
                },
                enabled = !isScraping && urlInput.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isScraping) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scraping...")
                } else {
                    Text("Add to Library")
                }
            }
        }
    }
}
