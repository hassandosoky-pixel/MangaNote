package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.ManhwaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManhwaDetailScreen(
    manhwaId: String,
    viewModel: ManhwaViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToReader: (String) -> Unit
) {
    val chapters by viewModel.getChapters(manhwaId).collectAsState(initial = emptyList())
    val downloadingChapters by viewModel.downloadingChapters.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chapters") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.8f)
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            items(chapters, key = { it.id }) { chapter ->
                val isDownloading = downloadingChapters.contains(chapter.id)
                ListItem(
                    headlineContent = { Text(chapter.title) },
                    supportingContent = {
                        if (chapter.isDownloaded) {
                            Text("Downloaded", color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text("Not downloaded")
                        }
                    },
                    trailingContent = {
                        if (isDownloading) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        } else if (!chapter.isDownloaded) {
                            Button(onClick = { viewModel.downloadChapter(chapter.id, chapter.url, manhwaId) }) {
                                Text("Download")
                            }
                        }
                    },
                    modifier = Modifier.clickable(enabled = chapter.isDownloaded) {
                        onNavigateToReader(chapter.id)
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
