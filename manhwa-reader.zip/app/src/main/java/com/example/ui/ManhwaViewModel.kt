package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChapterEntity
import com.example.data.local.ManhwaEntity
import com.example.data.local.PageEntity
import com.example.data.repository.ManhwaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ManhwaViewModel(private val repository: ManhwaRepository) : ViewModel() {

    val allManhwas: StateFlow<List<ManhwaEntity>> = repository.getAllManhwas()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _isScraping = MutableStateFlow(false)
    val isScraping: StateFlow<Boolean> = _isScraping.asStateFlow()
    
    private val _downloadingChapters = MutableStateFlow<Set<String>>(emptySet())
    val downloadingChapters: StateFlow<Set<String>> = _downloadingChapters.asStateFlow()

    fun addManhwaFromUrl(url: String) {
        viewModelScope.launch {
            _isScraping.value = true
            try {
                repository.scrapeAndSaveManhwa(url)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isScraping.value = false
            }
        }
    }

    fun getChapters(manhwaId: String): Flow<List<ChapterEntity>> {
        return repository.getChapters(manhwaId)
    }

    fun getPages(chapterId: String): Flow<List<PageEntity>> {
        return repository.getPages(chapterId)
    }

    fun downloadChapter(chapterId: String, url: String, manhwaId: String) {
        viewModelScope.launch {
            _downloadingChapters.value += chapterId
            try {
                repository.downloadChapter(chapterId, url, manhwaId)
            } finally {
                _downloadingChapters.value -= chapterId
            }
        }
    }
}

class ManhwaViewModelFactory(private val repository: ManhwaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ManhwaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ManhwaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
