package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ImmersivePrimary = Color(0xFFD0BCFF)
val ImmersiveOnPrimary = Color(0xFF381E72)
val ImmersiveBackground = Color(0xFF141218)
val ImmersiveOnBackground = Color(0xFFE6E1E5)
val ImmersiveSurface = Color(0xFF141218)
val ImmersiveOnSurface = Color(0xFFE6E1E5)
val ImmersiveSurfaceVariant = Color(0xFF2B2930)
val ImmersiveOnSurfaceVariant = Color(0xFFCAC4D0)
val ImmersiveOutline = Color(0xFF49454F)
val ImmersiveSecondaryContainer = Color(0xFFE8DEF8)
val ImmersiveOnSecondaryContainer = Color(0xFF1D192B)
