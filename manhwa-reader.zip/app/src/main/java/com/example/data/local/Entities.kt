package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "manhwas")
data class ManhwaEntity(
    @PrimaryKey val id: String, // e.g. URL slug
    val title: String,
    val coverUrl: String,
    val sourceUrl: String
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey val id: String, // e.g. URL
    val manhwaId: String,
    val title: String,
    val url: String,
    val isDownloaded: Boolean = false,
    val orderIndex: Int
)

@Entity(tableName = "pages")
data class PageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chapterId: String,
    val localFilePath: String,
    val orderIndex: Int
)

@Dao
interface ManhwaDao {
    @Query("SELECT * FROM manhwas")
    fun getAllManhwas(): Flow<List<ManhwaEntity>>

    @Query("SELECT * FROM manhwas WHERE id = :id")
    suspend fun getManhwaById(id: String): ManhwaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertManhwa(manhwa: ManhwaEntity)

    @Query("SELECT * FROM chapters WHERE manhwaId = :manhwaId ORDER BY orderIndex DESC")
    fun getChaptersForManhwa(manhwaId: String): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Query("UPDATE chapters SET isDownloaded = :isDownloaded WHERE id = :chapterId")
    suspend fun updateChapterDownloadedState(chapterId: String, isDownloaded: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<PageEntity>)

    @Query("SELECT * FROM pages WHERE chapterId = :chapterId ORDER BY orderIndex ASC")
    fun getPagesForChapter(chapterId: String): Flow<List<PageEntity>>
}
