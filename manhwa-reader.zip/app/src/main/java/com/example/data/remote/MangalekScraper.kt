package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.io.IOException

data class ScrapedManhwa(
    val title: String,
    val coverUrl: String,
    val chapters: List<ScrapedChapter>
)

data class ScrapedChapter(
    val title: String,
    val url: String,
    val orderIndex: Int
)

class MangalekScraper {
    private val userAgent = "Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"

    suspend fun getManhwaDetails(url: String): ScrapedManhwa = withContext(Dispatchers.IO) {
        val doc = Jsoup.connect(url)
            .userAgent(userAgent)
            .timeout(10000)
            .get()

        val title = doc.select("h1").firstOrNull()?.text() ?: "Unknown Title"
        val coverUrl = doc.select("img.wp-post-image, .summary_image img").attr("src").takeIf { it.isNotBlank() } ?: ""

        val chapters = mutableListOf<ScrapedChapter>()
        
        // Plausible selectors for common manga themes (Madara theme is very common for Mangalek and others)
        val chapterElements = doc.select("li.wp-manga-chapter, .lister .chap")
        chapterElements.forEachIndexed { index, element ->
            val link = element.select("a").firstOrNull()
            if (link != null) {
                chapters.add(
                    ScrapedChapter(
                        title = link.text().trim(),
                        url = link.attr("href"),
                        orderIndex = chapterElements.size - index // Assuming descending order on page
                    )
                )
            }
        }

        ScrapedManhwa(title, coverUrl, chapters)
    }

    suspend fun getChapterImages(chapterUrl: String): List<String> = withContext(Dispatchers.IO) {
        val doc = Jsoup.connect(chapterUrl)
            .userAgent(userAgent)
            .timeout(10000)
            .get()

        val imageUrls = mutableListOf<String>()
        
        // Selectors for reading pages
        val pageElements = doc.select(".reading-content img, .page-break img")
        pageElements.forEach { img ->
            var src = img.attr("data-src")
            if (src.isBlank()) src = img.attr("src")
            if (src.isNotBlank()) {
                imageUrls.add(src.trim())
            }
        }

        imageUrls
    }
}
