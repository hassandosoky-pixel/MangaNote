package com.example.data.repository

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class DownloadManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun downloadImageWithRetry(
        imageUrl: String,
        manhwaId: String,
        chapterId: String,
        pageIndex: Int,
        maxRetries: Int = 3
    ): String? = withContext(Dispatchers.IO) {
        val sanitizedManhwa = sanitizeFilename(manhwaId)
        val sanitizedChapter = sanitizeFilename(chapterId)
        val fileName = String.format("%03d.jpg", pageIndex)
        
        val dir = File(context.filesDir, "OfflineLibrary/$sanitizedManhwa/$sanitizedChapter")
        if (!dir.exists()) {
            dir.mkdirs()
        }

        val destFile = File(dir, fileName)
        if (destFile.exists() && destFile.length() > 0) {
            return@withContext destFile.absolutePath // Already downloaded
        }

        var attempt = 0
        while (attempt < maxRetries) {
            try {
                val request = Request.Builder()
                    .url(imageUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile Safari/537.36)")
                    .header("Referer", imageUrl) // Often required by manga sites
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val inputStream: InputStream? = response.body?.byteStream()
                    if (inputStream != null) {
                        val outputStream = FileOutputStream(destFile)
                        inputStream.use { input ->
                            outputStream.use { output ->
                                input.copyTo(output)
                            }
                        }
                        return@withContext destFile.absolutePath
                    }
                }
            } catch (e: Exception) {
                Log.e("DownloadManager", "Error downloading $imageUrl (Attempt ${attempt + 1})", e)
            }
            attempt++
            delay(1000L * attempt) // Exponential backoff
        }
        return@withContext null
    }

    private fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[^a-zA-Z0-9.-]"), "_")
    }
}
