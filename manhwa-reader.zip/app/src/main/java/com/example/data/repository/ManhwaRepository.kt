package com.example.data.repository

import android.content.Context
import android.util.Base64
import com.example.data.local.AppDatabase
import com.example.data.local.ChapterEntity
import com.example.data.local.ManhwaEntity
import com.example.data.local.PageEntity
import com.example.data.remote.MangalekScraper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class ManhwaRepository(
    private val database: AppDatabase,
    private val scraper: MangalekScraper,
    private val downloadManager: DownloadManager
) {
    private val manhwaDao = database.manhwaDao()

    fun getAllManhwas(): Flow<List<ManhwaEntity>> = manhwaDao.getAllManhwas()
    fun getChapters(manhwaId: String): Flow<List<ChapterEntity>> = manhwaDao.getChaptersForManhwa(manhwaId)
    fun getPages(chapterId: String): Flow<List<PageEntity>> = manhwaDao.getPagesForChapter(chapterId)

    suspend fun scrapeAndSaveManhwa(url: String): String = withContext(Dispatchers.IO) {
        val scraped = scraper.getManhwaDetails(url)
        val manhwaId = generateId(url)
        
        manhwaDao.insertManhwa(
            ManhwaEntity(
                id = manhwaId,
                title = scraped.title,
                coverUrl = scraped.coverUrl,
                sourceUrl = url
            )
        )

        val chapterEntities = scraped.chapters.map {
            ChapterEntity(
                id = generateId(it.url),
                manhwaId = manhwaId,
                title = it.title,
                url = it.url,
                orderIndex = it.orderIndex
            )
        }
        manhwaDao.insertChapters(chapterEntities)
        return@withContext manhwaId
    }

    suspend fun downloadChapter(chapterId: String, url: String, manhwaId: String) = withContext(Dispatchers.IO) {
        try {
            val imageUrls = scraper.getChapterImages(url)
            
            // Download images in parallel chunks to avoid overwhelming the network/site
            val chunkSize = 4
            val pageEntities = mutableListOf<PageEntity>()
            
            for ((chunkIndex, chunk) in imageUrls.chunked(chunkSize).withIndex()) {
                val deferredDownloads = chunk.mapIndexed { indexInChunk, imageUrl ->
                    val actualIndex = chunkIndex * chunkSize + indexInChunk
                    async {
                        val localPath = downloadManager.downloadImageWithRetry(
                            imageUrl = imageUrl,
                            manhwaId = manhwaId,
                            chapterId = chapterId,
                            pageIndex = actualIndex + 1
                        )
                        if (localPath != null) {
                            PageEntity(
                                chapterId = chapterId,
                                localFilePath = localPath,
                                orderIndex = actualIndex
                            )
                        } else null
                    }
                }
                
                val results = deferredDownloads.awaitAll().filterNotNull()
                pageEntities.addAll(results)
            }

            if (pageEntities.isNotEmpty()) {
                manhwaDao.insertPages(pageEntities)
                manhwaDao.updateChapterDownloadedState(chapterId, true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun generateId(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
