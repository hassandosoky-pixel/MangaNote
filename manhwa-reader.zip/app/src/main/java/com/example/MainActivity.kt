package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.remote.MangalekScraper
import com.example.data.repository.DownloadManager
import com.example.data.repository.ManhwaRepository
import com.example.ui.AppNavigation
import com.example.ui.ManhwaViewModel
import com.example.ui.ManhwaViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    
    val database = AppDatabase.getDatabase(this)
    val scraper = MangalekScraper()
    val downloadManager = DownloadManager(this)
    val repository = ManhwaRepository(database, scraper, downloadManager)
    
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: ManhwaViewModel = viewModel(factory = ManhwaViewModelFactory(repository))
        AppNavigation(viewModel)
      }
    }
  }
}

